"""Программа вычисляет минимальное количество платформ для перевозки роботов.

На вход передается массив, каждый элемент которого — это вес робота.
Второй параметр — это значение limit, грузоподъёмность одной платформы.

На одной платформе можно перевезти либо одного робота, либо двух — при условии,
что их совокупный вес не превышает limit. Роботы имеют разный вес.

ID посылки 133891428.
"""


def bubble_sort(data: list) -> list:
    """Функция сортирует элементы списка по возрастанию."""
    last_index: int = len(data) - 1
    swapped: bool = True

    while swapped:
        swapped = False
        for item_index in range(last_index):
            if data[item_index] > data[item_index + 1]:
                data[item_index], data[item_index + 1] = (
                    data[item_index + 1], data[item_index]
                )
                swapped = True
        last_index -= 1
    return data


def nessesary_platforms(data: list, max_weight: int) -> int:
    """Функция подсчитывает количество необходимых платформ."""
    left_point_index: int = 0
    right_point_index: int = len(data) - 1

    count: int = 0

    while left_point_index <= right_point_index:
        if data[right_point_index] + data[left_point_index] > max_weight:
            count += 1
            right_point_index -= 1

        else:
            count += 1
            right_point_index -= 1
            left_point_index += 1

    return count


if __name__ == '__main__':
    with open('input.txt', 'r') as file_in:
        data: list[int] = list(map(int, file_in.readline().strip().split()))
        limit: int = int(file_in.readline())
        bubble_sort(data)
        result = nessesary_platforms(data, limit)

    with open('output.txt', 'w') as file_out:
        file_out.write(str(result))
